﻿using System;

namespace MyLibrary
{
    public class StudentsDataIsNotCorrect : Exception
    {
    }
}
