﻿namespace MyLibrary
{
    public enum EducationalLevels
    {
        Bachelor,
        Specialist,
        Master
    }
}
